pip install discord.py==2.4.0


pip install colorama==0.4.6


pip install requests


pip install aiohttp

echo "Creditos a SZZ Store and Lost3r! https://discord.gg/ZVERbrk2HD"

pause