echo "creditos a SZZ Store and Lost3r! https://discord.gg/ZVERbrk2HD "

python cybersociety.py

pause
