# RAID PAINEL Cyber Society

Painel criado unicamente pra raids de servidor Discord.

# IMPORTANTE ! 

requirements

pip install discord.py==2.4.0


pip install colorama==0.4.6


pip install requests


pip install aiohttp


